package POM;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class login {

	WebDriver driver;
	
	@CacheLookup
	@FindBy(xpath ="//button[contains(text(),'D')]")
	WebElement popup;
	
	@CacheLookup
	@FindBy(id ="sign-in")
	WebElement signin;
	
	@CacheLookup
	@FindBy(id ="main_user_login")
	WebElement email;
	
	@CacheLookup
	@FindBy(name ="password")
	WebElement pass;
	
	@CacheLookup
	@FindBy(id ="login_button")
	WebElement login;

	@CacheLookup
	@FindBy(xpath ="//span[contains(text(),'Password must be 6 characters or more.')]")
	WebElement passworderror;
	
	@CacheLookup
	@FindBy(xpath ="//span[contains(text(),'email')]")
	WebElement emailerror;

	@CacheLookup
	@FindBy(id ="a_close_id")
	WebElement close;
	
	@CacheLookup
	@FindBy(xpath ="//input[@id='autocomplete']")
	WebElement productname1;
	
	@CacheLookup
	@FindBy(xpath ="//input[@id='autocomplete']")
	WebElement productname;
	
	@CacheLookup
	@FindBy(xpath ="//a[@class='srch_action btn orange']")
	WebElement search;
	
	@CacheLookup
	@FindBy(xpath ="//img[@onclick='homePageTracking(this);']")
	WebElement productclick;
	
	@CacheLookup
	@FindBy(xpath ="//span[@class='f_price']")
	WebElement productprice;
	
	
	@CacheLookup
	@FindBy(xpath ="//h1")
	WebElement productdetails;
	
	public login(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
    public void signinclose() {
    	close.click();
    }
	
	public void popupclose() {
		popup.click();
	}
	
	public void signin() {
		signin.click();
	}
	
	public void log(String Username , String password)
	{
		email.clear();
		email.sendKeys(Username);
		
		pass.clear();
		pass.sendKeys(password);	
		
		login.click();
	}
	
	public void proclear()
	{
		productname1.clear();

	}
	
	public void enterproduct(String product)
	{
		try {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    productname1.clear();

			productname1.sendKeys(product);
		    productname.clear();

			productname.sendKeys(product);
			search.click();
			productclick.click();
			
			ArrayList<String> newwindowtotal = new ArrayList<String>(driver.getWindowHandles()); 
			driver.switchTo().window(newwindowtotal.get(1));
			
			Reporter.log("Product Details = "+ productdetails.getText());
			Reporter.log("Product Price = "+ productprice.getText());
			//driver.close();
			//driver.switchTo().window(newwindowtotal.get(0));
			//driver.close();

		} catch (org.openqa.selenium.StaleElementReferenceException ex) {
			ex.printStackTrace();
		}
	}
	
	public void enterproduct1(String product)
	{
		try {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    productname1.clear();

			productname1.sendKeys(product);
		    productname.clear();

			productname.sendKeys(product);
			search.click();
			productclick.click();
			
			ArrayList<String> newwindowtotal = new ArrayList<String>(driver.getWindowHandles()); 
			driver.switchTo().window(newwindowtotal.get(1));
			
			Reporter.log("Product Details = "+ productdetails.getText());
			Reporter.log("Product Price = "+ productprice.getText());
			//driver.close();
			//driver.switchTo().window(newwindowtotal.get(0));
			//driver.close();

		} catch (org.openqa.selenium.StaleElementReferenceException ex) {
			ex.printStackTrace();
		}
	}
	public void passworderror()
	{
			String expecteduerror = "Password must be 6 characters or more.";
			String Actualerror = passworderror.getText();
			
			Reporter.log("Expected Error = "+ expecteduerror);
			Reporter.log("Actual Error = "+ Actualerror);
			assertTrue(Actualerror.equals(expecteduerror), "Mismatch in the error description");
	}
	
	public void emailerror()
	{
			String expecteduerror = "Please enter valid email id or mobile number.";
			String Actualerror = emailerror.getText();
			
			Reporter.log("Expected Error = "+ expecteduerror);
			Reporter.log("Actual Error = "+ Actualerror);
			assertTrue(Actualerror.equals(expecteduerror), "Mismatch in the error description");
	}
	
	public void passworderror1()
	{
			String expecteduerror = "Please enter your password.";
			String Actualerror = passworderror.getText();
			
			Reporter.log("Expected Error = "+ expecteduerror);
			Reporter.log("Actual Error = "+ Actualerror);
			assertTrue(Actualerror.equals(expecteduerror), "Mismatch in the error description");
	}
	
	public void emailerror1()
	{
			String expecteduerror = "Please enter email id or mobile number.";
			String Actualerror = emailerror.getText();
			
			Reporter.log("Expected Error = "+ expecteduerror);
			Reporter.log("Actual Error = "+ Actualerror);
			assertTrue(Actualerror.equals(expecteduerror), "Mismatch in the error description");
	}
	
	public void robotheadphone() {
driver.get("https://www.shopclues.com/");
		
		Robot rbt = null;
		try {
			rbt = new Robot();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.xpath("//input[@id='autocomplete']")).sendKeys("");
		rbt.keyPress(KeyEvent.VK_H);
		rbt.keyRelease(KeyEvent.VK_H);
		rbt.keyPress(KeyEvent.VK_E);
		rbt.keyRelease(KeyEvent.VK_E);
		rbt.keyPress(KeyEvent.VK_A);
		rbt.keyRelease(KeyEvent.VK_A);
		rbt.keyPress(KeyEvent.VK_D);
		rbt.keyRelease(KeyEvent.VK_D);
		rbt.keyPress(KeyEvent.VK_P);
		rbt.keyRelease(KeyEvent.VK_P);
		rbt.keyPress(KeyEvent.VK_H);
		rbt.keyRelease(KeyEvent.VK_H);
		rbt.keyPress(KeyEvent.VK_O);
		rbt.keyRelease(KeyEvent.VK_O);
		rbt.keyPress(KeyEvent.VK_N);
		rbt.keyRelease(KeyEvent.VK_N);
		rbt.keyPress(KeyEvent.VK_E);
		rbt.keyRelease(KeyEvent.VK_E);
		
		
		//rbt.keyPress(KeyEvent.VK_TAB);
		//rbt.keyPress(KeyEvent.VK_ENTER);
		
		//search.click();
	}
	
	
	public void countno() {
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
WebElement count = driver.findElement(By.className("countNo"));

String expectedcount = "Showing 10672 Results";
String Actualcount = count.getText();

Reporter.log("Expected count = "+ expectedcount);
Reporter.log("Actual count = "+ Actualcount);
assertTrue(Actualcount.equals(expectedcount), "Mismatch in the count description");
		
	}
	
	public void close() {
		ArrayList<String> newwindowtotal = new ArrayList<String>(driver.getWindowHandles()); 
		driver.switchTo().window(newwindowtotal.get(3));
		driver.close();
		driver.switchTo().window(newwindowtotal.get(2));
		driver.close();
		driver.switchTo().window(newwindowtotal.get(1));
		driver.close();
		driver.switchTo().window(newwindowtotal.get(0));
		driver.close();
	}
}
