package Test;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import POM.login;

public class Loginvalidation extends Base {
	login lgn;

	@BeforeClass
	public void beforeclass() {
		lgn = new login(driver);
	}

	@BeforeMethod
	public void beforemethod() {
		try {
			Thread.sleep(2000);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	}

	@Test
	public void popupclosed() {
		lgn.popupclose();
		Reporter.log("Able to close pop up successfully");
	}

	@Test
	public void sign() {

		lgn.signin();
		Reporter.log("Able to click sign in successfully");
	}

	@Parameters({"Invalidusername", "Invalidpassword"})	
	@Test(dependsOnMethods = { "sign" })
	public void Inloginvalidation(String username , String password) {

		lgn.log(username, password);
		lgn.emailerror();
		lgn.passworderror();

	}

	@Parameters({"validusername", "Invalidpassword"})	
	@Test(dependsOnMethods = { "sign" })
	public void Inpassloginvalidation(String username , String password) {

		lgn.log(username, password);  
		lgn.passworderror();


	}

	@Parameters({"Invalidusername", "validpassword"})	
	@Test(dependsOnMethods = { "sign" })
	public void Inuserloginvalidation(String username , String password) {

		lgn.log(username, password);  
		lgn.emailerror();
	}

	@Parameters({"validpassword"})	
	@Test(dependsOnMethods = { "sign" })
	public void blankuserloginvalidation( String password) {

		lgn.log("",password);  
		lgn.emailerror1();
	}

	@Parameters({"validusername"})	
	@Test(dependsOnMethods = { "sign" })
	public void blankpassloginvalidation(String username) {

		lgn.log(username, ""); 
		lgn.passworderror1();
	}

	@Test(dependsOnMethods = { "blankpassloginvalidation" })
	public void signwindowclosed() {
		lgn.signinclose();
	}

	//	<parameter name ="Product" value="nike shoes" ></parameter>
	//<parameter name ="Producta" value="fast track watches" ></parameter>
	//<parameter name ="Productb" value="apple phones" ></parameter>
	//@Parameters({"Product"})	

	@Test(dependsOnMethods = { "signwindowclosed" })
	public void searchproducts() {
		lgn.proclear();
		lgn.enterproduct("nike shoes");
	}

	//@Parameters({"Producta"})	
	@Test(dependsOnMethods = { "searchproducts" })
	public void searchproducts1() {
		driver.get("https://www.shopclues.com/");

		//lgn.proclear();
		WebElement product = driver.findElement(By.xpath("//input[@id='autocomplete']"));
		product.sendKeys("fast track watches");
		WebElement search = driver.findElement(By.xpath("//a[@class='srch_action btn orange']"));
		search.click();
		WebElement productclick = driver.findElement(By.xpath("//img[@onclick='homePageTracking(this);']"));
		productclick.click();
		ArrayList<String> newwindowtotal = new ArrayList<String>(driver.getWindowHandles()); 
		driver.switchTo().window(newwindowtotal.get(2));

		WebElement productprice = driver.findElement(By.xpath("//span[@class='f_price']"));
		WebElement productdetails = driver.findElement(By.xpath("//h1"));

		//lgn.searchprd();

		//lgn.proclear();
		//lgn.enterproduct1("fast track watches");


		Reporter.log("Product Details = "+ productdetails.getText());
		Reporter.log("Product Price = "+ productprice.getText());

	}

	//@Parameters({"Productb"})	
	@Test(dependsOnMethods = { "searchproducts1" })
	public void searchproducts2() {
		driver.get("https://www.shopclues.com/");

		//lgn.proclear();
		WebElement product = driver.findElement(By.xpath("//input[@id='autocomplete']"));
		product.sendKeys("apple phones");
		WebElement search = driver.findElement(By.xpath("//a[@class='srch_action btn orange']"));
		search.click();
		WebElement productclick = driver.findElement(By.xpath("//img[@onclick='homePageTracking(this);']"));
		productclick.click();
		ArrayList<String> newwindowtotal = new ArrayList<String>(driver.getWindowHandles()); 
		driver.switchTo().window(newwindowtotal.get(3));

		WebElement productprice = driver.findElement(By.xpath("//span[@class='f_price']"));
		WebElement productdetails = driver.findElement(By.xpath("//h1"));

		//lgn.searchprd();

		//lgn.proclear();
		//lgn.enterproduct1("fast track watches");


		Reporter.log("Product Details = "+ productdetails.getText());
		Reporter.log("Product Price = "+ productprice.getText());

	}

	@Test(dependsOnMethods = { "searchproducts2" })
	public void enterheadphone() {
		lgn.robotheadphone();
		WebElement search = driver.findElement(By.xpath("//a[@class='srch_action btn orange']"));
		search.click();
	}
	
	@Test(dependsOnMethods = { "enterheadphone" })
	public void count() {
		lgn.countno();

	}

	@Test(dependsOnMethods = { "count" })
	public void windowclosed() {
		lgn.close();

	}
}
