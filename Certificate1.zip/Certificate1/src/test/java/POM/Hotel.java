package POM;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Hotel {

	WebDriver driver;
	
	@CacheLookup
	@FindBy(xpath ="//i[@class='icon-hotels db blue ico28 lh1-2 padT2 padB3']")
	WebElement clickhotel;
	
	@CacheLookup
	@FindBy(xpath ="//input[@placeholder ='e.g. - Area, Landmark or Hotel Name']")
	WebElement hotelname;

	@CacheLookup
	@FindBy(xpath ="//a[@data-action-id='c81994ec']")
	WebElement alert;
	
	@CacheLookup
	@FindBy(xpath ="//div[@data-testid='openCheckinCalendar']")
	WebElement calendar;
	
	@CacheLookup
	@FindBy(xpath ="//ul[@class='dcalendarstyles__DateWrapDiv-r2jz2t-7 jXPZCe']//li/span[text()='28']")
	WebElement checkin;
	
	@CacheLookup
	@FindBy(xpath ="//ul[@class='dcalendarstyles__DateWrapDiv-r2jz2t-7 jXPZCe']//li/span[text()='30']")
	WebElement checkout;
	
	@CacheLookup
	@FindBy(xpath ="//input[@class='SearchBlockUIstyles__CitySearchInput-fity7j-12 gPhhhX']")
	WebElement Guest;
	
	@CacheLookup
	@FindBy(xpath ="(//span[@class='PaxWidgetstyles__ContentActionIconWrapperSpan-gv3w6r-8 cNEHNd'])[3]")
	WebElement countofGuest;
	
	@CacheLookup
	@FindBy(xpath ="//button[@class='dwebCommonstyles__ButtonBase-sc-112ty3f-10 PaxWidgetstyles__ButtonWrapper-gv3w6r-11 dTNRom dFUOpX']")
	WebElement confirm;
	
	@CacheLookup
	@FindBy(xpath ="//button[@data-testid='searchHotelBtn']")
	WebElement searchhotel;
	
	@CacheLookup
	@FindBy(xpath ="(//h4[@class='dwebCommonstyles__SmallSectionHeader-sc-112ty3f-7 jevUjk'])[1]")
	WebElement hotelname1;
	
	@CacheLookup
	@FindBy(xpath ="(//h4[@class='dwebCommonstyles__SmallSectionHeader-sc-112ty3f-7 jevUjk'])[1]")
	WebElement hotelname2;
	
	@CacheLookup
	@FindBy(xpath ="(//button[@class='dwebCommonstyles__ButtonBase-sc-112ty3f-10 RoomFlavorstyles__ButtonWrapper-sc-1btnl3r-15 dTNRom bCgKhF'])[1]")
	WebElement slctroom;
	
	@CacheLookup
	@FindBy(xpath ="//input[@placeholder='Enter First Name']")
	WebElement ftname;
	
	@CacheLookup
	@FindBy(xpath ="//input[@placeholder='Enter Last Name']")
	WebElement ltname;
	
	@CacheLookup
	@FindBy(xpath ="//input[@placeholder='Enter Email Address']")
	WebElement email;
	
	@CacheLookup
	@FindBy(xpath ="//input[@placeholder='Enter Phone Number']")
	WebElement phno;
	
	@CacheLookup
	@FindBy(xpath ="//button[@class='dwebCommonstyles__ButtonBase-sc-112ty3f-10 GuestDetailsBlockstyles__CustomButton-sc-1rzm4ar-6 dTNRom hvAOPy']")
	WebElement detailenter;
	
	

	
	public void guestdetails(String firstname , String lastname, String emailid, String phonenumber)
	{
		ftname.sendKeys(firstname);
		
		ltname.sendKeys(lastname);
		
		email.sendKeys(emailid);
		
		phno.sendKeys(phonenumber);
	
	}
	
	public void detailsenter()
	{
	
		detailenter.click();
	}
	
	public void slectroom() {
		
		slctroom.click();
	}
	
	public void serachotels() {
		
		searchhotel.click();
	}
	
public String hotename() {
		
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return hotelname1.getText();
	
	}

public String hotename1() {
	
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return hotelname2.getText();
	
	}
	
public void hotenameclick() {
	
	try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	hotelname1.click();
	
	}

public void changewindow() {
	
	ArrayList<String> newwindowtotal = new ArrayList<String>(driver.getWindowHandles()); 

	driver.switchTo().window(newwindowtotal.get(1));
	
}
public void changewindow1() {
	
	ArrayList<String> newwindowtotal = new ArrayList<String>(driver.getWindowHandles()); 

	driver.switchTo().window(newwindowtotal.get(2));
	
}


public void guestandroom() {
	
	Guest.click();
	try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	countofGuest.click();
	confirm.click();
}
	
	public void popup() 
	{
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("//iframe[@name='notification-frame-~251442c09']")));
	WebElement element=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[contains(@class ,'wewidgeticon')]")));
	element.click();
	}
	
	public Hotel(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void clickhotels()
	
	{

		clickhotel.click();	
	}
	
	public void place(String Place) {
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		hotelname.sendKeys(Place);
	}
	
public void checkincheckout()
	
	{

		calendar.click();	
		checkin.click();
		checkout.click();
	}
	
}
