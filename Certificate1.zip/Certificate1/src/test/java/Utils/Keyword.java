package Utils;

import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URI;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.net.Urls;

import Test.URL;

public class Keyword {

WebDriver driver;
	
	public Keyword(WebDriver driver) {
		this.driver = driver;
	}
	
	public void entercardetails(String carduumber , String name , String expirydate, String CVV )
	{
		driver.findElement(By.xpath("//input[@placeholder='Card Number']")).sendKeys(carduumber);

		driver.findElement(By.xpath("//input[@placeholder='Name']")).sendKeys(name);
		
		driver.findElement(By.xpath("//input[@placeholder='MM / YY']")).sendKeys(expirydate);
		
		driver.findElement(By.xpath("//input[@placeholder='CVV NO.']")).sendKeys(CVV);
	}
	
	public void pay() {
	driver.findElement(By.xpath("(//button[contains(text(),'Pay')])[1]")).click();
	}
	
	public String newhotelname()
	{
		WebElement htlname1 = driver.findElement(By.xpath("//h1"));
		System.out.println("Hotel name :- "+ htlname1.getText());
		return htlname1.getText();
		
	}	
	
public void roomoptions () {
		
		driver.findElement(By.xpath("//a[contains(text(),'Room Options')]")).click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}

public void clicklocation() {
	
	driver.findElement(By.xpath("//a[contains(text(),'Location')]")).click();
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public String clicklocationtext() {

	WebElement location = driver.findElement(By.xpath("(//a[@class='dwebCommonstyles__PrimaryLink-sc-112ty3f-8 cKRTHq'])[13]"));
	return location.getText();
}

public String clicklocationtext1() {

	WebElement location1 = driver.findElement(By.xpath("(//a[@class='dwebCommonstyles__PrimaryLink-sc-112ty3f-8 cKRTHq'])[14]"));
	return location1.getText();
}
	
public void Guestreviews() {
	
	driver.findElement(By.xpath("//a[contains(text(),'Guest Reviews')]")).click();
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public String overallrating() {

	WebElement overallrating = driver.findElement(By.xpath("//span[@class='GuestReview__AvgReviewTextWrapper-sc-1twl4uk-5 bgiXRC']"));
	return overallrating.getText();
}

public String fiverating() {

	WebElement fiverating = driver.findElement(By.xpath("(//div[@class='RatingsBreakupstyles__ProgressBarCountWrapper-jukzyv-3 fKdYSo'])[1]"));
	return fiverating.getText();
}

public void Amenities() {
	
driver.findElement(By.xpath("//a[contains(text(),'Amenities')]")).click();
try {
	Thread.sleep(3000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

}

public String Amenitiestext() {
WebElement Amenities = driver.findElement(By.xpath("(//span[@class='Amenitiesstyles__AmenityItemText-sc-10opy4a-8 iwRmcg'])[1]"));
return Amenities.getText();
		
}


public void policy() {
	driver.findElement(By.xpath("//a[@data-testid='navigation-header-cta-#hotel-policies']")).click();

	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public String policytext() {
	
driver.findElement(By.xpath("(//a[@class='ContentContainerstyles__ViewMoreTextStyled-jinyls-1 bymaaz'])[1]")).click();
	
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	WebElement Policy = driver.findElement(By.xpath("(//span[@class='Policystyles__PolicyTextStyled-sc-1vd94lq-7 icgafC'])[1]"));
	return Policy.getText();
}

public void payathotel()

{
	driver.findElement(By.xpath("(//span[contains(text(),'Pay At Hotel')])[1]")).click();
	
	try {
		Thread.sleep(10000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public String payathotelname() {
	
	WebElement htlname1 = driver.findElement(By.xpath("(//h4[@class='dwebCommonstyles__SmallSectionHeader-sc-112ty3f-7 jevUjk'])[1]"));
	return htlname1.getText();
}

public void pricerange() {
	
	driver.findElement(By.xpath("(//div[@class='CheckBoxList__TextCenteredDiv-sc-5k7440-1 FIwlQ'])[2]")).click();
	
}

public String pricerangedetails() {
	
	
	WebElement pricerange = driver.findElement(By.xpath("//div[@class='Chip-o2aze2-0 kLlkpl']"));
	return pricerange.getText();
}

public void clearfilters() {
	
	driver.findElement(By.xpath("//span[@class='Filtersstyles__ClearTextSpan-bkjigy-2 kjwPuU']")).click();

}

public void customerrating() {
	
	driver.findElement(By.xpath("(//div[@class='CheckBoxList__TextCenteredDiv-sc-5k7440-1 FIwlQ'])[7]")).click();
		
}

public String customerratingdetails() {
	
		
	WebElement ratings = driver.findElement(By.xpath("//div[@class='Chip-o2aze2-0 kLlkpl']"));
return ratings.getText();
}

public void close() {
	ArrayList<String> newwindowtotal = new ArrayList<String>(driver.getWindowHandles()); 
	driver.switchTo().window(newwindowtotal.get(2));
	driver.close();
	driver.switchTo().window(newwindowtotal.get(1));
	driver.close();
	driver.switchTo().window(newwindowtotal.get(0));
	driver.close();
}



	public void imagesave() {
	try {
	WebElement logo = driver.findElement(By.cssSelector("img[class='Roomstyles__RoomImageStyled-sc-1ivl7fs-6 eKaeMj']"));
	 String logoSRC = logo.getAttribute("https://cdn1.goibibo.com/voy_ing/t_g/eb211b28bb0a11e8847d0285a8598958.jpg");

	// BufferedImage saveImage = ImageIO.read(imageurl);

	// ImageIO.write(saveImage, "png", new File("logo-image.png"));
	}
	catch(Exception e) {
        e.printStackTrace();
        
	}
	}	
}
