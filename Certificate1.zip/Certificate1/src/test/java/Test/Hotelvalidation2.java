package Test;

import org.testng.annotations.Test;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import POM.Hotel;
import Utils.Keyword;

public class Hotelvalidation2 extends Base {
	Hotel htl;
	Keyword kw;

	@BeforeClass
	public void beforeclass() {
		htl = new Hotel(driver);
		kw = new Keyword(driver);

	}

	@BeforeMethod
	public void beforemethod() {
		try {
			Thread.sleep(3000);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	@Test
	public void openurl(){
		
		driver.get("https://www.goibibo.com/");
		Reporter.log("URL opened ");

	}
	
	
	@Test (dependsOnMethods = { "openurl" })
	public void openhotelpage(){
		
		htl.clickhotels(); 
		
		Reporter.log("Clicked on Hotel button");

	}
	
	
	@Parameters({"Placename"})	
	@Test (dependsOnMethods = { "openhotelpage" })
	public void Enterplacename(String placename){
		
		htl.place(placename); 
		Reporter.log("Place name entered successfully");

	}
	
	@Test (dependsOnMethods = { "Enterplacename" })
	public void selectplacename(){
		Robot rbt = null;
		try {
			rbt = new Robot();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		rbt.keyPress(KeyEvent.VK_DOWN);
		rbt.keyPress(KeyEvent.VK_ENTER);
		
		Reporter.log("Place selected successfully");
	}
	
	@Test (dependsOnMethods = { "selectplacename" })
	public void calendardate(){
		
		htl.checkincheckout();
		Reporter.log("Check in and check out date selected successfully");
	}
	
	@Test (dependsOnMethods = { "calendardate" })
	public void guestroomdetails(){
		
		htl.guestandroom();
		Reporter.log("Guest room details selected successfully");
	}
	
	@Test (dependsOnMethods = { "guestroomdetails" })
	public void search(){
		
		htl.serachotels();
		Reporter.log("Clicked on Search hotels successfully");
	}
	
	
	@Test (dependsOnMethods = { "search" })
	public void hotelnameprint(){
		
		String hotelname = htl.hotename();
		
		Reporter.log("Hotel name :- " + hotelname );
		
	}

	@Test (dependsOnMethods = { "hotelnameprint" })
	public void hotelnameclick(){

		htl.hotenameclick();
		Reporter.log("Hotel clicked successfully");

	}

	@Test (dependsOnMethods = { "hotelnameclick" })
	public void windowmanage(){

		htl.changewindow();
		Reporter.log("Window changed successfully");

	}

	@Test (dependsOnMethods = { "windowmanage" })
	public void pagedown(){
		Robot rbt = null;
		try {
			rbt = new Robot();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		rbt.keyPress(KeyEvent.VK_PAGE_DOWN);
		
		Reporter.log("Page down selected successfully");
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test (dependsOnMethods = { "pagedown" })
	public void selectroom(){
		
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		htl.slectroom();
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Reporter.log("Room selected successfully");

	}

	@Parameters({"firstname" ,"lastname", "emailid", "phonenumber" })	
	@Test (dependsOnMethods = { "selectroom" })
	public void guestdetailsentered(String firstname , String lastname, String emailid, String phonenumber){
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		htl.guestdetails(firstname, lastname, emailid, phonenumber);
		Reporter.log("Enter guest details successfully");

	}

	@Test (dependsOnMethods = { "guestdetailsentered" })
	public void guestdetailenter(){
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		htl.detailsenter();
		
		Reporter.log("Click on guest details");

	}
	

	@Parameters({"carduumber" ,"firstname", "expirydate", "CVV" })	
	@Test (dependsOnMethods = { "guestdetailenter" })
	public void carddetailsentered(String carduumber , String name , String expirydate, String CVV ){
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
kw.entercardetails(carduumber, name, expirydate, CVV);	

		Reporter.log("Card details entered successfully");

	}
	
	@Test (dependsOnMethods = { "carddetailsentered" })
	public void payclick( ){
		
		
kw.pay();
		Reporter.log("Clicked on pay successfully");

	}

}
