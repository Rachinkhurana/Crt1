package Test;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.net.Urls;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URI;

import javax.imageio.ImageIO;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import POM.Hotel;
import Utils.Keyword;

public class Hotelvalidation3 extends Base {
	Hotel htl;
	Keyword kw;

	@BeforeClass
	public void beforeclass() {
		htl = new Hotel(driver);
		kw = new Keyword(driver);

	}

	@BeforeMethod
	public void beforemethod() {
		try {
			Thread.sleep(3000);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	@Test
	public void openurl(){
		
		driver.get("https://www.goibibo.com/");
		Reporter.log("URL opened ");

	}
	
	
	@Test (dependsOnMethods = { "openurl" })
	public void openhotelpage(){
		
		htl.clickhotels(); 
		
		Reporter.log("Clicked on Hotel button");

	}
	
	
	@Parameters({"Placename"})	
	@Test (dependsOnMethods = { "openhotelpage" })
	public void Enterplacename(String placename){
		
		htl.place(placename); 
		Reporter.log("Place name entered successfully");

	}
	
	@Test (dependsOnMethods = { "Enterplacename" })
	public void selectplacename(){
		Robot rbt = null;
		try {
			rbt = new Robot();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		rbt.keyPress(KeyEvent.VK_DOWN);
		rbt.keyPress(KeyEvent.VK_ENTER);
		
		Reporter.log("Place selected successfully");
	}
	
	@Test (dependsOnMethods = { "selectplacename" })
	public void calendardate(){
		
		htl.checkincheckout();
		Reporter.log("Check in and check out date selected successfully");
	}
	
	@Test (dependsOnMethods = { "calendardate" })
	public void guestroomdetails(){
		
		htl.guestandroom();
		Reporter.log("Guest room details selected successfully");
	}
	
	@Test (dependsOnMethods = { "guestroomdetails" })
	public void search(){
		
		htl.serachotels();
		Reporter.log("Clicked on Search hotels successfully");
	}
	
	
	@Test (dependsOnMethods = { "search" })
	public void hotelnameprint(){
		
		String hotelname = htl.hotename();
		
		Reporter.log("Hotel name :- " + hotelname );
	}
	
	@Test (dependsOnMethods = { "hotelnameprint" })
	public void hotelnameclick(){

		htl.hotenameclick();
		Reporter.log("Hotel clicked successfully");

	}

	@Test (dependsOnMethods = { "hotelnameclick" })
	public void windowmanage(){

		htl.changewindow1();
		Reporter.log("Window changed successfully");

	}

	@Test (dependsOnMethods = { "windowmanage" })
	public void Hotelnameonnewpage(){
	
		String hotel = kw.newhotelname();
		Reporter.log("Hotel name :- " + hotel);
		
	}

	@Test (dependsOnMethods = { "Hotelnameonnewpage" })
	public void roomandrates(){
	
		kw.roomoptions();
		Reporter.log(" Clicked on Room and option");
		
	}
		
	@Test (dependsOnMethods = { "roomandrates" })
	public void locationverify(){
	
		kw.clicklocation();
		Reporter.log(" Clicked on Locations");
		
		String locationtext = kw.clicklocationtext();
		Reporter.log("Near by Attraction :- " + locationtext);
		String locationtext1 = kw.clicklocationtext1();
		Reporter.log("Near by Transit :- " + locationtext1);
	}	 
	
	@Test (dependsOnMethods = { "locationverify" })
	public void guestreviewsverification(){
	
		kw.Guestreviews();
		Reporter.log(" Clicked on Guest and reviews");
		
		String overall = kw.overallrating();
		Reporter.log("Overall Ratings :- " + overall);
		
		String fivestar = kw.fiverating();
		Reporter.log("5 Star Ratings :- " + fivestar);
	}	
	
	@Test (dependsOnMethods = { "guestreviewsverification" })
	public void Amenitiesverification(){
	
		kw.Amenities();
		Reporter.log(" Clicked on Amenities");
		
		String Amenitiestext = kw.Amenitiestext();
		Reporter.log("Amenities 1 :- " + Amenitiestext);
	}	
	
	@Test (dependsOnMethods = { "Amenitiesverification" })
	public void Policyverification(){
	
		kw.policy();
		Reporter.log(" Clicked on Hotel Policy");
		
		String policytext = kw.policytext();
		Reporter.log("Policy 1 :- " + policytext);
	}
	
		
	}

