package Test;

import static org.testng.Assert.assertTrue;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class Basicvalidation extends Base {
	
	@Test
	public void URLvalidation() {
		String expectedurl = "https://www.goibibo.com/";
		String Actualurl = driver.getCurrentUrl();
		
		Reporter.log("Expected URL = "+ expectedurl);
		Reporter.log("Actual URL = "+ Actualurl);
		
		assertTrue(Actualurl.equals(expectedurl), "Mismatch in the URL");
	}
	
	@Test
	public void titlevalidation() {
		String expectedttl = "Goibibo - Best Travel Website. Book Hotels, Flights, Trains, Bus and Cabs with upto 50% off";
		String Actualttl = driver.getTitle();
		Reporter.log("Expected title = "+ expectedttl);
		Reporter.log("Actual title = "+ Actualttl);
		
		assertTrue(Actualttl.equals(expectedttl), "Mismatch in the URL");
	}
  }


