package com.edureka.Cucumber_case_study;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;





public class StepDefinitions  {

	String browser = "chrome";
	String baseUrl = "https://whatfix.com/";
	
	WebDriver driver;
	


	@Before
	public void setupBrowser() {

		String currDir = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", currDir+"\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();	
		driver.get(baseUrl);
		driver.manage().window().maximize();
	}
	
	@After
	public void tearDown() {
		driver.quit();
	}


	@Given("Open the website")
	public void open_the_website() {
		driver.navigate().to(baseUrl);
	}

	@When("Verify that the website is opened")
	public void verify_that_the_website_is_opened() {
System.out.println("Title of Page : " + driver.getTitle());
	}

	@Then("Website opened successfully")
	public void website_opened_successfully() {
		String expectedurl = "https://whatfix.com/";
		String Actualurl = driver.getCurrentUrl();
      if (expectedurl == Actualurl) 
      {
    	  System.out.println("Test case passed");
      }
	}
	@Given("click on customers")
	public void click_on_customers() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   driver.findElement(By.xpath("//span[contains(text(),'Customers')]")).click();
	}

	@When("Verify that the customer is opened")
	public void verify_that_the_customer_is_opened() {
		System.out.println("Title of Page : " + driver.getTitle());

	}

	@Then("customer opened successfully")
	public void customer_opened_successfully() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String expectedurl = "https://whatfix.com/reviews/";
		String Actualurl = driver.getCurrentUrl();
      if (expectedurl == Actualurl) 
      {
    	  System.out.println("Test case customer is passed");
      }
	}

	@Given("click on Pricing")
	public void click_on_Pricing() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	   driver.findElement(By.xpath("//span[contains(text(),'Pricing')]")).click();
	}

	@When("Verify that the Pricing is opened")
	public void verify_that_the_Pricing_is_opened() {
		System.out.println("Title of Page : " + driver.getTitle());

	}

	@Then("Pricing opened successfully")
	public void Pricing_opened_successfully() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String expectedurl = "https://whatfix.com/pricing/";
		String Actualurl = driver.getCurrentUrl();
      if (expectedurl == Actualurl) 
      {
    	  System.out.println("Test case Pricing is passed");
      }
	}
	
	@Given("click on Partners")
	public void click_on_Partners() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	   driver.findElement(By.xpath("//span[contains(text(),'Partners')]")).click();
	}

	@When("Verify that the Partners is opened")
	public void verify_that_the_Partners_is_opened() {
		System.out.println("Title of Page : " + driver.getTitle());

	}

	@Then("Partners opened successfully")
	public void Partners_opened_successfully() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String expectedurl = "https://whatfix.com/partners/";
		String Actualurl = driver.getCurrentUrl();
      if (expectedurl == Actualurl) 
      {
    	  System.out.println("Test case Partners is passed");
      }
	}
	
	@Given("click on Resources")
	public void click_on_Resources() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	   driver.findElement(By.xpath("//span[contains(text(),'Resources')]")).click();
	}

	@When("Verify that the Resources is opened")
	public void verify_that_the_Resources_is_opened() {
		System.out.println("Title of Page : " + driver.getTitle());

	}

	@Then("Resources opened successfully")
	public void Resources_opened_successfully() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String expectedurl = "https://whatfix.com/resources/";
		String Actualurl = driver.getCurrentUrl();
      if (expectedurl == Actualurl) 
      {
    	  System.out.println("Test case Resources is passed");
      }
	}
}
