package Test;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import POM.login;
import Utils.Keyword;

public class Basicvalidation extends Base {

	login lgn;
	Keyword kw;

	@BeforeClass
	public void beforeclass() {
		lgn = new login(driver);
		kw = new Keyword(driver);
	}

	@BeforeMethod
	public void thread()
	{
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test()
	public void OPEN_URL() {
		String expectedUrl = "https://www.91mobiles.com/";
		String actualUrl = kw.getCurrentPageUrl();
		kw.compareStrings(expectedUrl, actualUrl);
		Reporter.log("Able to open URL successfully");
	}
	
	@Test(dependsOnMethods = { "OPEN_URL" })
	public void ENTER_TEXT() {
		kw.serachapple().sendKeys("Apple Mobile");
		Reporter.log("Able to enter successfully");

	}
	
	@Test(dependsOnMethods = { "ENTER_TEXT" })
	public void CLICK() {
		kw.clicksearch().click();
		Reporter.log("Able to search successfully");
	}
	
	@Test(dependsOnMethods = { "CLICK" })
	public void VERIFY_TEXT() {
		String expectedtext = "Showing 114 results for apple mobile in all categories";
		String actualtext = kw.count().getText();
		kw.compareStrings(expectedtext, actualtext);
		Reporter.log("Text verified successfully");
		
	}
	
//PRINT_TEXT

	@Test(dependsOnMethods = { "VERIFY_TEXT" })
	public void PRINT_TEXT() {
		
		String mobile = kw.print().getAttribute("title");
		System.out.println("Print the mobile name : " + mobile);
		Reporter.log("Text print successfully");

	}
	
	@Test(dependsOnMethods = { "PRINT_TEXT" })
	public void close() {
	kw.close();	
	Reporter.log("Browser closed successfully");

	}
	
}



