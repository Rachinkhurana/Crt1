package Utils;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import pom.Login;

public class Keyword {
	WebDriver driver;

	public Keyword(WebDriver driver) {
		this.driver = driver;
	}

	/**
	 * This method is used to compare two Strings
	 * @param expectedString :	Expected String output
	 * @param actualString :	Actual String displayed in the application
	 */

	public void compareStrings(String expectedString, String actualString) {
		Reporter.log("Expected String = "+expectedString);
		Reporter.log("Actual String = "+actualString);
		assertTrue(actualString.equals(expectedString), "Mismatch in the Strings.");

	}

	public String getCurrentPageUrl() {
		return driver.getCurrentUrl();
	}

	public String getCurrentPageTitle() {
		return driver.getTitle();
	}

	public WebElement serachapple() {
		WebElement elem= driver.findElement(By.id("autoSuggestTxtBox"));
		//elem.sendKeys("Apple Mobile");
		return elem;
	}	
	
	public WebElement clicksearch() {
		WebElement elem= driver.findElement(By.id("main_auto_search"));
		//elem.sendKeys("Apple Mobile");
		return elem;
	}	

	public WebElement count() {
		WebElement elem= driver.findElement(By.id("productCount"));
		//elem.sendKeys("Apple Mobile");
		return elem;
	}
	
	public WebElement print() {
		WebElement elem= driver.findElement(By.xpath("//a[@title='Apple iPhone 11']"));
		//elem.sendKeys("Apple Mobile");
		return elem;
	}
	
	public void close() {
		driver.close();
	}
}






















