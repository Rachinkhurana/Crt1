package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class login {

	WebDriver driver;
	
	@CacheLookup
	@FindBy(xpath ="//button[@class='_2KpZ6l _2doB4z']")
	WebElement modal;
	
	//@CacheLookup
	//@FindBy(id ="pass")
	//WebElement pass;

	public login(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void modal()
	{
		modal.click();
	}
}
